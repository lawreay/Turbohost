<section class="subpage-hero">
  <div class="container">
    <p class="section-kicker">Pricing</p>
    <h1>Simple hosting plans for students, creators, churches, and growing businesses in Malawi.</h1>
    <p>Start with a free plan to launch your first website, then upgrade when your audience, storage, or business needs grow.</p>
  </div>
</section>

<section class="page-section">
  <div class="container">
    <?php include APP_PATH . '/Views/marketing/partials/pricing-cards.php'; ?>
  </div>
</section>
