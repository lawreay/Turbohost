<?php
$value = static fn (string $key, string $default = ''): string => htmlspecialchars($settings[$key] ?? $default, ENT_QUOTES, 'UTF-8');
$checked = static fn (string $key, string $default = '0'): string => (($settings[$key] ?? $default) === '1') ? 'checked' : '';
$heroImage = $value('homepage_hero_image', 'https://images.pexels.com/photos/30530403/pexels-photo-30530403.jpeg?auto=compress&cs=tinysrgb&w=1280');
$heroVideo = trim((string) ($settings['homepage_hero_video'] ?? ''));
?>
<section class="marketing-hero">
  <div class="container">
    <div class="row align-items-center g-5">
      <div class="col-lg-6 reveal">
        <p class="section-kicker"><?= $value('homepage_hero_kicker', 'AFFORDABLE WEBSITE HOSTING FOR MALAWI') ?></p>
        <h1 class="display-4 fw-bold"><?= $value('homepage_hero_title', 'Build, host, and launch your website without the usual stress.') ?></h1>
        <p class="lead text-white-50"><?= $value('homepage_hero_subtitle', 'TurboHostMw helps students, churches, small businesses, freelancers, and NGOs in Malawi create a strong online presence with simple tools, fast publishing, and dependable hosting.') ?></p>
        <div class="d-flex flex-wrap gap-3 mt-4">
          <a class="btn btn-primary btn-lg" href="<?= htmlspecialchars(($app['base_url'] ?? '') . '/register', ENT_QUOTES, 'UTF-8') ?>"><?= $value('homepage_cta_text', 'Start Your Free Site') ?></a>
          <a class="btn btn-outline-light btn-lg" href="<?= htmlspecialchars(($app['base_url'] ?? '') . '/login', ENT_QUOTES, 'UTF-8') ?>"><?= $value('homepage_secondary_cta_text', 'Sign In') ?></a>
          <a class="btn btn-outline-light btn-lg" href="<?= htmlspecialchars(($app['base_url'] ?? '') . '/pricing', ENT_QUOTES, 'UTF-8') ?>">See Plans</a>
        </div>
        <p class="mt-4 text-white-50">Perfect for anyone in Malawi who wants a website that looks professional and is easy to manage.</p>
      </div>
      <div class="col-lg-6 reveal reveal-delay-1 position-relative">
        <div class="hero-media-frame rounded-4 overflow-hidden shadow-lg">
          <?php if ($heroVideo !== ''): ?>
            <video class="hero-video" autoplay muted loop playsinline poster="<?= $heroImage ?>">
              <source src="<?= htmlspecialchars($heroVideo, ENT_QUOTES, 'UTF-8') ?>" type="video/mp4">
              Your browser does not support HTML video.
            </video>
          <?php else: ?>
            <img src="<?= $heroImage ?>" alt="Homepage hero visual" class="img-fluid w-100">
          <?php endif; ?>
        </div>
        <div class="floating-badge badge-html">HTML</div>
        <div class="floating-badge badge-css">CSS</div>
        <div class="floating-badge badge-js">JS</div>
        <div class="floating-badge badge-php">PHP</div>
      </div>
    </div>
  </div>
</section>

<section class="stats-band">
  <div class="container">
    <div class="row g-4 text-center">
      <div class="col-6 col-lg-3"><strong>10,000+</strong><span>Websites Hosted</span></div>
      <div class="col-6 col-lg-3"><strong>5,000+</strong><span>Users</span></div>
      <div class="col-6 col-lg-3"><strong>50+</strong><span>Countries</span></div>
      <div class="col-6 col-lg-3"><strong>99.9%</strong><span>Platform Availability</span></div>
    </div>
  </div>
</section>

<section class="page-section">
  <div class="container">
    <div class="row g-5 align-items-center">
      <div class="col-lg-6 reveal">
        <p class="section-kicker">Built for Malawi</p>
        <h2>Simple website tools for schools, shops, churches, and growing brands.</h2>
        <p class="text-secondary">Whether you are creating a portfolio, a church outreach page, a school notice board, or a small business website, TurboHostMw helps you share your work online without needing advanced technical skills.</p>
        <ul class="feature-list mt-4">
          <li><i data-lucide="check-circle"></i> Quick setup with beginner-friendly controls</li>
          <li><i data-lucide="check-circle"></i> Upload files and publish your site in minutes</li>
          <li><i data-lucide="check-circle"></i> Keep your online presence professional and easy to maintain</li>
        </ul>
      </div>
      <div class="col-lg-6 reveal reveal-delay-1">
        <div class="feature-card h-100">
          <i data-lucide="sparkles"></i>
          <h3>Made for everyday users</h3>
          <p>You do not need to be a web developer to launch a strong website. TurboHostMw is designed to make publishing feel clear, practical, and local.</p>
        </div>
      </div>
    </div>
  </div>
</section>

<section class="page-section">
  <div class="container">
    <div class="text-center section-heading">
      <p class="section-kicker">How It Works</p>
      <h2>Launch Your Website in 3 Steps</h2>
    </div>
    <div class="row g-4">
      <div class="col-md-4">
        <div class="feature-card reveal">
          <i data-lucide="plus-circle"></i>
          <h3>Create Project</h3>
          <p>Create a website using the built-in editor and starter structure.</p>
        </div>
      </div>
      <div class="col-md-4">
        <div class="feature-card reveal reveal-delay-1">
          <i data-lucide="upload"></i>
          <h3>Upload Files</h3>
          <p>Manage HTML, CSS, JavaScript, images, and media from your dashboard.</p>
        </div>
      </div>
      <div class="col-md-4">
        <div class="feature-card reveal reveal-delay-2">
          <i data-lucide="globe-2"></i>
          <h3>Publish</h3>
          <p>Get your website online instantly with a TurboHostMw subdomain.</p>
        </div>
      </div>
    </div>
  </div>
</section>

<section class="page-section section-muted" id="features">
  <div class="container">
    <div class="text-center section-heading">
      <p class="section-kicker"><?= $value('homepage_section_heading', 'Features') ?></p>
      <h2><?= $value('homepage_section_subheading', 'Everything You Need') ?></h2>
    </div>
    <div class="row g-4">
      <?php foreach ([
        ['code-2', 'Built-in Code Editor', 'Syntax highlighting, project files, and live preview.'],
        ['folder-open', 'File Manager', 'Upload and organize files easily.'],
        ['server', 'Website Hosting', 'Fast and reliable hosting with a simple publishing flow.'],
        ['bar-chart-3', 'Analytics', 'Track visitors and traffic as your project grows.'],
        ['link', 'Custom Domains', 'Connect a custom domain on Premium.'],
        ['shield-check', 'Secure Platform', 'Protected with modern security and validation.'],
      ] as $item): ?>
        <div class="col-md-6 col-lg-4">
          <div class="feature-card h-100 reveal">
            <i data-lucide="<?= htmlspecialchars($item[0], ENT_QUOTES, 'UTF-8') ?>"></i>
            <h3><?= htmlspecialchars($item[1], ENT_QUOTES, 'UTF-8') ?></h3>
            <p><?= htmlspecialchars($item[2], ENT_QUOTES, 'UTF-8') ?></p>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<section class="page-section">
  <div class="container">
    <div class="row g-5 align-items-center">
      <div class="col-lg-6 reveal">
        <div class="dashboard-preview">
          <img src="https://images.pexels.com/photos/30530403/pexels-photo-30530403.jpeg?auto=compress&cs=tinysrgb&w=1280" alt="TurboHostMw dashboard showcase" class="img-fluid rounded-4 shadow">
        </div>
      </div>
      <div class="col-lg-6 reveal reveal-delay-1">
        <p class="section-kicker">Powerful Dashboard</p>
        <h2>Manage websites, files, and billing in one place.</h2>
        <ul class="feature-list mt-4">
          <li><i data-lucide="check-circle"></i> Website management</li>
          <li><i data-lucide="check-circle"></i> File uploads and storage insights</li>
          <li><i data-lucide="check-circle"></i> Traffic analytics and reports</li>
          <li><i data-lucide="check-circle"></i> Billing controls and plan upgrades</li>
          <li><i data-lucide="check-circle"></i> Project settings and publishing tools</li>
        </ul>
      </div>
    </div>
  </div>
</section>

<section class="page-section section-muted" id="pricing">
  <div class="container">
    <div class="text-center section-heading">
      <p class="section-kicker">Pricing</p>
      <h2>Simple Pricing</h2>
    </div>
    <?php include APP_PATH . '/Views/marketing/partials/pricing-cards.php'; ?>
  </div>
</section>

<section class="page-section" id="templates">
  <div class="container">
    <div class="text-center section-heading">
      <p class="section-kicker">Templates</p>
      <h2>Start With Templates</h2>
    </div>
    <div class="row g-4">
      <?php foreach ([
        ['Business Website', 'https://images.pexels.com/photos/461073/pexels-photo-461073.jpeg?auto=compress&cs=tinysrgb&w=800'],
        ['Portfolio', 'https://images.pexels.com/photos/326514/pexels-photo-326514.jpeg?auto=compress&cs=tinysrgb&w=800'],
        ['Church Website', 'https://images.pexels.com/photos/69432/pexels-photo-69432.jpeg?auto=compress&cs=tinysrgb&w=800'],
        ['School Website', 'https://images.pexels.com/photos/5621952/pexels-photo-5621952.jpeg?auto=compress&cs=tinysrgb&w=800'],
        ['Blog', 'https://images.pexels.com/photos/7394719/pexels-photo-7394719.jpeg?auto=compress&cs=tinysrgb&w=800'],
        ['Landing Page', 'https://images.pexels.com/photos/3584973/pexels-photo-3584973.jpeg?auto=compress&cs=tinysrgb&w=800'],
      ] as $template): ?>
        <div class="col-sm-6 col-lg-4">
          <div class="template-card reveal">
            <img src="<?= htmlspecialchars($template[1], ENT_QUOTES, 'UTF-8') ?>" alt="<?= htmlspecialchars($template[0], ENT_QUOTES, 'UTF-8') ?>" class="img-fluid rounded-3">
            <p class="mt-3 fw-semibold mb-0"><?= htmlspecialchars($template[0], ENT_QUOTES, 'UTF-8') ?></p>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<section class="cta-section">
  <div class="container text-center">
    <h2>Ready To Launch Your Website?</h2>
    <p>Create your account and start building today.</p>
    <a class="btn btn-light btn-lg" href="<?= htmlspecialchars(($app['base_url'] ?? '') . '/register', ENT_QUOTES, 'UTF-8') ?>">Start Free</a>
  </div>
</section>
