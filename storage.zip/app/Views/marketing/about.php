<section class="subpage-hero">
  <div class="container">
    <p class="section-kicker">About</p>
    <h1>Professional website hosting made for Malawi.</h1>
    <p>TurboHostMw was created to help people and organizations in Malawi build an online presence with less confusion, more confidence, and a platform that is simple to use.</p>
  </div>
</section>

<section class="page-section">
  <div class="container">
    <div class="row g-4 align-items-center">
      <div class="col-lg-6">
        <h2>We believe online presence should be practical and accessible.</h2>
        <p class="text-secondary">From small businesses and churches to students and NGOs, many people need a website but do not want to struggle with complicated hosting tools. TurboHostMw gives you a clear path to publish your content, manage your files, and grow your online presence in a way that feels manageable.</p>
      </div>
      <div class="col-lg-6">
        <div class="about-panel">
          <div><strong>Simple</strong><span>Fast setup and easy controls</span></div>
          <div><strong>Secure</strong><span>Modern protection for uploads and accounts</span></div>
          <div><strong>Flexible</strong><span>Built to grow with your project</span></div>
        </div>
      </div>
    </div>
  </div>
</section>
