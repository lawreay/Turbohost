# Deployment Notes

- The app uses Apache `.htaccess` rewrite rules in the project root to route requests into `public/`.
- Recommended deployment steps:
  1. Pull code to server.
  2. Run `composer install --no-dev`.
  3. Ensure `public/` is the webroot and `.htaccess` is present.
  4. Set environment variables in the server environment (not in repo `.env`).
  5. Ensure writable directories: `storage/`, `public/sites/`, `public/uploads/`.

Blue-green deploy considerations:
- Keep `public/sites` on shared storage or replicate content between releases.
- Use `sitemap` regeneration as post-deploy hook.

Maintainer:
- Lawrence Phuka — adminphukal@mau.adventist.org