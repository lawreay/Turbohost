# Setup & Local Development

Prerequisites:
- PHP >= 8.0 with PDO and required extensions
- Composer
- Webserver (Apache recommended for Rewrite rules)
- MySQL or compatible database

Quick local steps:
1. Clone the repo to `C:/wamp64/www/TurboHostMw`.
2. Copy `.env.example` to `.env` and set DB and mail credentials.
3. Run `composer install`.
4. Ensure `public/` is the web root or use the provided `.htaccess` rewrite rules.
5. Create the database and run migrations using `database/schema.sql`.
6. Start local server or use WAMP/XAMPP and point DocumentRoot to `public`.

Common commands:
```bash
composer install
php -S localhost:8000 -t public
```

Notes:
- If database is remote, ensure `app/Config/database.php` env values are set.
- Logging and cache files go to `storage/`.

Maintainer:
- Lawrence Phuka — adminphukal@mau.adventist.org