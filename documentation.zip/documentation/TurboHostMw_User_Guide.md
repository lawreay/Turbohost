# TurboHostMw User Guide
## For Clients - Complete Platform Documentation

---

## Table of Contents
1. [Platform Overview](#platform-overview)
2. [Getting Started](#getting-started)
3. [Dashboard Overview](#dashboard-overview)
4. [Creating Your First Website](#creating-your-first-website)
5. [Managing Website Files](#managing-website-files)
6. [Editing Website Content](#editing-website-content)
7. [Publishing Your Website](#publishing-your-website)
8. [Pricing Plans](#pricing-plans)
9. [Account Management](#account-management)
10. [Security Features](#security-features)
11. [Troubleshooting](#troubleshooting)
12. [Support](#support)

---

## Platform Overview

### What is TurboHostMw?

TurboHostMw is a complete website hosting and management platform designed for everyone—from beginners to experienced developers. You can:

- **Create and host websites** without technical knowledge
- **Manage files** with our intuitive file manager
- **Edit content** directly through the web editor
- **Preview changes** before publishing
- **Upgrade to premium** for more features and storage

### Key Features

✓ **Easy Website Creation** - Start with templates or from scratch  
✓ **File Management** - Upload, organize, and manage all your website files  
✓ **Web Editor** - Edit HTML, CSS, and JavaScript directly  
✓ **Live Preview** - See your changes before publishing  
✓ **Automatic Publishing** - Go live with one click  
✓ **Custom Domains** - Use your own domain name  
✓ **Secure Hosting** - SSL/HTTPS support  
✓ **Storage Management** - Track and manage your storage usage  
✓ **Notifications** - Stay updated on important events  

---

## Getting Started

### Account Creation & Login

#### Step 1: Create an Account

1. Visit the TurboHostMw homepage
2. Click **"Register"** or go to the registration page
3. Enter your:
   - Full Name
   - Email Address
   - Strong Password (minimum 8 characters recommended)
   - Confirm Password
4. Click **"Create Account"**
5. You'll receive a confirmation email - click the verification link
6. Your account is ready to use!

#### Step 2: Login

1. Go to the login page
2. Enter your email and password
3. If you have Two-Factor Authentication enabled, enter the verification code
4. Click **"Login"**

### Email Verification

Your email address is crucial for account recovery and important notifications:

- Check your inbox for the verification email
- Click the verification link within 24 hours
- If you don't receive it, click "Resend Verification Email"

### Recovering Your Password

Forgot your password? No problem:

1. Click **"Forgot Password?"** on the login page
2. Enter your email address
3. Check your email for the password reset link
4. Click the link and create a new password
5. Use your new password to login

---

## Dashboard Overview

Once logged in, you'll see your personal dashboard:

### Dashboard Components

**Top Navigation Bar:**
- Your account menu (avatar/name)
- Logout button
- Quick access to settings

**Left Sidebar Menu:**
- **Dashboard** - Your main overview page
- **My Websites** - All your hosted projects
- **Notifications** - System messages and alerts
- **My Profile** - Account settings and security
- **Billing** - Subscription and payment info

### Main Dashboard Display

Your dashboard shows:

1. **Welcome Message** - Personalized greeting with your name
2. **Storage Usage** - Visual indicator of used vs. available storage
3. **Plan Information** - Current plan (Free or Premium)
4. **Recent Websites** - Your latest projects
5. **Activity Summary** - Key statistics:
   - Number of active websites
   - Total files stored
   - Current storage usage

---

## Creating Your First Website

### Step 1: Navigate to Website Creation

1. Click **"My Websites"** in the left sidebar
2. Click the **"Create New Website"** button (or **"+"** icon)
3. You'll see the website creation form

### Step 2: Choose a Template

Select how you want to start:

- **Blank Template** - Start from scratch with basic HTML files
- **Pre-built Templates** - Choose from professional website templates
- **Import Template** - Upload your own template files

### Step 3: Configure Your Website

Fill in the following information:

| Field | Description | Required |
|-------|-------------|----------|
| Website Name | Your project name (internal reference) | Yes |
| Website URL Slug | URL-friendly name for your subdomain | No |
| Template | Choose a starting template | Yes |

### Step 4: Confirm and Create

1. Review your choices
2. Click **"Create Website"**
3. Your website is created and ready to edit!

**Note:** Free plan accounts can create up to 3 active websites. Upgrade to Premium for unlimited websites.

---

## Managing Website Files

### Understanding the File Manager

The file manager is where you organize all your website content:

- **Directory Tree** - Shows your folder structure on the left
- **File List** - Displays files and folders in the current directory
- **Action Buttons** - Tools to manage your files

### File Manager Features

#### Uploading Files

**Single File Upload:**
1. Click **"Upload File"** button
2. Select one file from your computer
3. Choose the destination folder
4. File uploads automatically

**Multiple Files Upload:**
1. Click **"Upload Multiple Files"**
2. Select several files at once
3. All files upload to the selected folder

**Drag and Drop:**
- Simply drag files from your computer into the file manager window
- Drop them in the desired folder

#### Creating Files and Folders

**Create a New Folder:**
1. Navigate to the parent folder
2. Click **"New Folder"**
3. Enter the folder name
4. Press Enter

**Create a New File:**
1. Click **"New File"**
2. Enter the filename with extension (e.g., `about.html`, `style.css`)
3. The file is created empty and ready to edit

#### Organizing Files

**Move Files/Folders:**
1. Select the file or folder
2. Click **"Move"**
3. Choose the destination folder
4. Confirm the action

**Rename Files:**
1. Right-click or select the file
2. Click **"Rename"**
3. Enter the new name
4. Press Enter

**Delete Files:**
1. Select the file or folder
2. Click **"Delete"** (or press Delete key)
3. Confirm deletion
⚠️ **Warning:** Deleted files cannot be recovered!

#### Downloading Files

**Download Individual File:**
1. Select the file
2. Click **"Download"**
3. The file saves to your computer

**Download All Files (Zip Archive):**
1. Click **"Export as ZIP"**
2. All website files are packaged
3. The ZIP file downloads automatically

#### Importing Files

**Import ZIP Archive:**
1. Click **"Import ZIP"**
2. Select a ZIP file from your computer
3. Choose where to extract files
4. All files are extracted to your website

### Storage Limits

**Free Plan:**
- 500 MB total storage
- Perfect for small websites and blogs

**Premium Plan:**
- 50 GB total storage
- Ideal for large projects with media files

Your dashboard shows your current storage usage. If you exceed your limit, you'll need to delete files or upgrade your plan.

---

## Editing Website Content

### Opening the Web Editor

1. Go to **"My Websites"**
2. Find your website
3. Click **"Edit"** or the edit icon
4. The web editor opens in a new tab

### The Web Editor Interface

**Left Panel:**
- File tree of your website
- Quick access to all files
- Click any file to open it for editing

**Center Panel:**
- Code editor with syntax highlighting
- Line numbers for easy reference
- Auto-complete suggestions

**Right Panel:**
- File properties and details
- Quick actions

### Editing Your Code

#### Common File Types

| File Type | Purpose |
|-----------|---------|
| `.html` | Website structure and content |
| `.css` | Styling and layout |
| `.js` | Interactive features and functionality |
| `.json` | Configuration and data files |
| `.txt` | Text documents |

#### Basic Editing

1. Click the file in the file tree
2. The file opens in the code editor
3. Make your changes
4. Click **"Save"** (or Ctrl+S / Cmd+S)
5. A confirmation message appears

#### Navigation Features

- **Go to Line:** Press Ctrl+G to jump to a specific line number
- **Search:** Press Ctrl+F to find text in the current file
- **Replace:** Press Ctrl+H to find and replace text
- **Quick File Switch:** Press Ctrl+P to search for files

#### Keyboard Shortcuts

| Shortcut | Action |
|----------|--------|
| Ctrl+S / Cmd+S | Save file |
| Ctrl+Z / Cmd+Z | Undo |
| Ctrl+Y / Cmd+Y | Redo |
| Ctrl+F | Find |
| Ctrl+H | Replace |
| Ctrl+G | Go to line |
| Tab | Indent |
| Shift+Tab | Outdent |

### Visual Preview

#### Live Preview Panel

Some files show a live preview:

- **HTML files** - See rendered webpage
- **CSS changes** - Appear in real-time
- **JavaScript** - Runs in the preview

**To enable preview:**
1. Open an HTML file
2. Click the **"Preview"** panel on the right
3. Your webpage appears live

#### Full Page Preview

1. From your website dashboard
2. Click **"Preview Website"**
3. Opens in a new tab showing your live site
4. Scroll and interact to test everything
5. Check that all links and features work

---

## Publishing Your Website

### What is Publishing?

Publishing makes your website live and accessible on the internet. Before publishing, your website is private (draft mode).

### Publishing Your Website

#### Step 1: Review Your Website

1. Click **"Preview Website"** from your website dashboard
2. Check all pages and links
3. Test all interactive features
4. Ensure everything looks correct

#### Step 2: Publish

1. Return to your website dashboard
2. Look for the **"Publish"** button (or status indicator)
3. Click **"Publish Website"**
4. Confirm the action

#### Step 3: Your Website is Live!

Once published:
- Your website is accessible to anyone
- You can share your website URL
- Google and other search engines can index it
- Your subdomain is: `yourusername.turbohosemw.com`

### Custom Domains

Connect your own domain name:

1. Go to **Website Settings**
2. Click **"Custom Domain"**
3. Enter your domain (e.g., `mysite.com`)
4. Follow the DNS configuration instructions
5. Wait 24-48 hours for DNS to propagate

### Unpublishing Your Website

To take your website offline:

1. Go to your website dashboard
2. Click **"Unpublish"**
3. Confirm the action
4. Your website is no longer accessible online
5. Your files remain safely stored

### Version Control

Your website automatically saves versions:
- Every time you publish, a backup is created
- You can revert to previous versions if needed
- Backups are stored on our secure servers

---

## Pricing Plans

### Free Plan

Perfect for getting started:

- ✓ Up to 3 active websites
- ✓ 500 MB storage
- ✓ Free subdomain (yourname.turbohosemw.com)
- ✓ Basic file management
- ✓ Web editor access
- ✓ Email support

**Perfect for:** Beginners, portfolios, small blogs

### Premium Plan

For serious projects:

- ✓ Unlimited websites
- ✓ 50 GB storage
- ✓ Custom domain support
- ✓ Advanced file management
- ✓ Priority support
- ✓ Advanced analytics
- ✓ Dedicated resources
- ✓ 99.9% uptime guarantee

**Perfect for:** Businesses, large projects, professional portfolios

### Upgrading to Premium

#### Method 1: From Dashboard

1. Click your profile icon (top right)
2. Go to **"Billing"** or **"Upgrade Plan"**
3. Click **"Upgrade to Premium"**
4. Choose billing cycle (monthly or annual)
5. Complete payment
6. Premium features activate immediately

#### Method 2: From Website Creation

If you try to create more than 3 websites on the Free plan:

1. You'll see an upgrade suggestion
2. Click **"Upgrade to Premium"**
3. Follow the payment process
4. You can then create more websites

### Payment Methods

We accept:
- Credit/Debit Cards (Visa, MasterCard, American Express)
- PayChangu Mobile Money
- Bank Transfers
- Digital Wallets

### Billing & Invoices

- View your subscription status in **"Billing"**
- Download invoices anytime
- Automatic renewal on your billing date
- Cancel anytime (no long-term contracts)

---

## Account Management

### Profile Settings

#### Updating Your Profile

1. Click your name/avatar (top right)
2. Select **"My Profile"**
3. Edit your information:
   - Full name
   - Username
   - Email address
   - Profile photo

4. Click **"Save Changes"**

#### Changing Your Password

1. Go to **"My Profile"**
2. Click **"Security"** section
3. Click **"Change Password"**
4. Enter your current password
5. Enter your new password (twice)
6. Click **"Update Password"**

**Password Requirements:**
- Minimum 8 characters
- Mix of uppercase and lowercase letters
- Include numbers or special characters
- Different from your previous passwords

#### Changing Your Email

1. Go to **"My Profile"**
2. Click **"Change Email"**
3. Enter your new email address
4. Verify your current password
5. Click **"Send Verification"**
6. Check your new email for a confirmation link
7. Click the link to confirm the change

### Account Deactivation

**Warning:** Deactivation is permanent and cannot be undone.

To deactivate your account:

1. Go to **"My Profile"**
2. Scroll to the bottom
3. Click **"Deactivate Account"**
4. Read the warning carefully
5. Confirm by entering your password
6. Click **"Permanently Deactivate"**

**What happens when you deactivate:**
- Your websites are taken offline
- Your files are archived for 90 days
- Your account cannot be recovered
- Subscriptions are cancelled

---

## Security Features

### Two-Factor Authentication (2FA)

Add an extra layer of security to your account:

#### Enabling 2FA

1. Go to **"My Profile"**
2. Click **"Security"**
3. Select **"Enable Two-Factor Authentication"**
4. Use an authenticator app (Google Authenticator, Authy, Microsoft Authenticator)
5. Scan the QR code with your app
6. Enter the 6-digit code
7. 2FA is now active

#### Using 2FA

Each login now requires:
1. Email and password
2. 6-digit code from your authenticator app
3. You're logged in

**Keep your authenticator app safe!** If you lose access, you won't be able to login.

### Login Security Best Practices

1. **Strong Password** - Use unique, complex passwords
2. **Don't Share Credentials** - Never share your login information
3. **Public WiFi** - Avoid logging in on public networks
4. **Log Out** - Always logout when done
5. **Update Browser** - Keep your browser updated
6. **Verify URLs** - Always check you're on the correct website

### Backup Your Website

#### Automatic Backups

- Your website is automatically backed up daily
- Backups are stored on secure servers
- Up to 30 days of backup history

#### Manual Backups

To download your website files:

1. Go to your website
2. Click **"File Manager"**
3. Click **"Export as ZIP"**
4. All files download as a ZIP archive
5. Store safely on your computer

---

## Notifications

### Notification Types

You'll receive notifications for:

- **Security Alerts** - Login from new device, password changes
- **Payment Updates** - Subscription renewals, failed payments
- **Website Updates** - Publishing/unpublishing, storage alerts
- **System Maintenance** - Scheduled downtime notices
- **Important Updates** - Feature releases, important announcements

### Managing Notifications

#### View Notifications

1. Click **"Notifications"** in the left sidebar
2. See all recent notifications
3. Click a notification for details

#### Notification Preferences

1. Go to **"My Profile"**
2. Click **"Notification Settings"**
3. Choose what you want to receive:
   - Email notifications
   - In-app notifications
   - Marketing emails
   - Security alerts

4. Click **"Save Preferences"**

---

## Troubleshooting

### Common Issues and Solutions

#### I Can't Login

**Problem:** Receiving "Invalid credentials" error

**Solutions:**
1. Check that you're entering the correct email
2. Verify Caps Lock is off
3. Try resetting your password
4. Clear your browser cache and cookies
5. Try a different browser
6. Check your internet connection

#### My Website Files Disappeared

**Problem:** Can't find my files in the file manager

**Solutions:**
1. Refresh the page (Ctrl+F5 or Cmd+Shift+R)
2. Check if you're in the correct folder
3. Look in trash or deleted files
4. Contact support (we may be able to recover them)

#### My Website Won't Publish

**Problem:** Getting an error when trying to publish

**Solutions:**
1. Check that you have at least one HTML file
2. Ensure your index.html file exists
3. Verify file names don't have special characters
4. Check available storage space
5. Try publishing again in a few minutes
6. Contact support if problem persists

#### Website is Very Slow

**Problem:** Website loads slowly or times out

**Solutions:**
1. Optimize images (reduce file size)
2. Remove unused files
3. Check file structure and organize files
4. Minimize CSS and JavaScript files
5. Upgrade to Premium for better resources
6. Contact support

#### I Exceeded My Storage Limit

**Problem:** Getting storage limit error

**Solutions:**
1. Delete unused files
2. Remove duplicate files
3. Optimize or compress large media files
4. Download and backup old files
5. Upgrade to Premium plan (50 GB storage)

#### Email Verification Not Working

**Problem:** Didn't receive verification email

**Solutions:**
1. Check spam/junk folder
2. Wait a few minutes (emails can take time)
3. Click "Resend Verification Email"
4. Check you entered the correct email
5. Contact support with your email address

#### Payment Processing Failed

**Problem:** Payment was declined during checkout

**Solutions:**
1. Verify card details are correct
2. Check card has available credit/funds
3. Contact your bank
4. Try a different payment method
5. Try again in a few minutes
6. Contact support for assistance

---

## Tips & Best Practices

### Website Organization

- **Use clear folder names** - Organize files logically (css/, images/, js/)
- **Meaningful filenames** - Use descriptive names (homepage.html not page1.html)
- **Backup regularly** - Download ZIP backup monthly
- **Version control** - Keep track of changes you make

### Performance Optimization

- **Optimize images** - Use appropriate formats and sizes
- **Minimize files** - Reduce CSS and JavaScript file size
- **Clean code** - Remove unnecessary comments and spacing
- **Reduce HTTP requests** - Combine files where possible

### Security Best Practices

- **Update software** - Keep browser and OS updated
- **Use HTTPS** - Enable SSL for custom domains
- **Regular backups** - Keep local copies of important files
- **Strong passwords** - Use unique passwords for your account

### Content Best Practices

- **Clear navigation** - Users should easily find pages
- **Mobile responsive** - Test on phones and tablets
- **Fast loading** - Minimize file sizes and requests
- **Fresh content** - Update regularly to keep users engaged

---

## Support & Getting Help

### Support Channels

#### Email Support
- **Address:** support@turbohostemw.com
- **Response time:** 24-48 hours
- **Best for:** Complex issues, billing questions

#### Help Center
- Browse articles and tutorials
- Search for solutions
- Find step-by-step guides

#### Contact Form
- Fill out through our website
- Describe your issue in detail
- Attach screenshots if helpful

### Getting Quick Answers

**FAQ Section:**
Most common questions are answered in our FAQ page. Check there first!

**Knowledge Base:**
Searchable article library covering:
- Account management
- File management
- Website creation
- Troubleshooting
- Best practices

### When Contacting Support

To help us assist you quickly, include:

1. **Your email address** - Account identifier
2. **What you were doing** - Steps that led to the issue
3. **Error messages** - Exact error text
4. **Screenshots** - Visual reference
5. **Device/browser** - What you're using
6. **When it happened** - Date and time

---

## Terms & Legal

### Terms of Service

Your use of TurboHostMw is governed by our Terms of Service. Key points:

- **Acceptable Use** - No illegal content, malware, or spam
- **Uptime Guarantee** - Premium: 99.9% | Free: Best effort
- **Responsibility** - You're responsible for your content
- **Liability Limits** - We're not liable for data loss (maintain backups)
- **Termination** - We can terminate for violations

### Privacy Policy

We take your privacy seriously:

- **Data Collection** - We collect only necessary information
- **Usage** - Your data is used to improve services
- **Sharing** - We don't sell your data to third parties
- **Security** - We use industry-standard encryption
- **Your Rights** - You can request, modify, or delete your data

### Intellectual Property

- **Your Content** - You retain rights to your website content
- **Our Property** - Platform code and features are our property
- **Fair Use** - Don't copy or redistribute our services

---

## Conclusion

Congratulations! You now know how to use TurboHostMw to create, manage, and publish your websites.

### Quick Start Recap

1. ✓ Create your account
2. ✓ Create your first website
3. ✓ Upload or create files
4. ✓ Edit your content
5. ✓ Preview your website
6. ✓ Publish and go live!

### Next Steps

- **Explore templates** - Choose a design that matches your vision
- **Customize your site** - Make it uniquely yours
- **Share your URL** - Let others see your work
- **Learn more** - Check our tutorials and help center
- **Upgrade** - Consider Premium when ready for more power

### Stay Connected

- **Check notifications** - Stay updated on important events
- **Read our blog** - Learn about new features and tips
- **Follow us** - Get announcements on social media
- **Provide feedback** - Help us improve your experience

---

## Contact Information

**TurboHostMw Support Team**

- 📧 Email: phukal@mau.adventist.org
- 🌐 Website: www.turbohostmw.com
- 💬 Live Chat: Available on our website
- 📞 Phone: +1-XXX-XXX-XXXX

**Office Hours:** Monday-Friday, 9 AM - 5 PM (Local Time)

---

*Last Updated: 2026*  
*TurboHostMw - Your Website Hosting Made Simple*
