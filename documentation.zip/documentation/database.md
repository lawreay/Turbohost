# Database & Schema Notes

Primary tables of interest (see `database/schema.sql`):
- `users`
- `websites` (id, user_id, website_name, slug, subdomain, custom_domain, storage_used, bandwidth_used, status, expires_at, created_at)
- `files` (tracks published/draft file paths)
- `platform_settings`
- `two_factor_codes`, `subscriptions`, `payments`

Operational guidance:
- Backups: `storage/backups/` recommended; Periodic SQL dumps and filesystem backups for `storage/` and `public/sites/`.
- Migrations: no migration runner present; changes must be applied manually using SQL files.

Indexes & performance:
- Index `websites(status)`, `files(website_id)`, `notifications(user_id, read_at)`.

Maintainer:
- Lawrence Phuka — adminphukal@mau.adventist.org