# TurboHostMw Quick Start Guide
## Get Your Website Live in 5 Minutes

---

## What is TurboHostMw?

TurboHostMw is your complete website hosting solution. Whether you're a beginner or experienced developer, you can:
- **Create websites** with templates or from scratch
- **Upload files** using our easy file manager
- **Edit content** with our built-in code editor
- **Preview changes** before publishing
- **Go live** with one click
- **Manage everything** from your dashboard

---

## First Time? Start Here

### Step 1: Create Your Account (1 minute)

1. Visit **turbohostmw.com**
2. Click **"Register"**
3. Enter your email and create a password
4. Check your email for verification link
5. **You're in!**

### Step 2: Create Your First Website (2 minutes)

1. Click **"My Websites"** → **"Create New"**
2. Enter website name (e.g., "My Portfolio")
3. Choose template or start blank
4. Click **"Create"**
5. **Your website is ready!**

### Step 3: Add Your Content (1 minute)

**Option A - Upload Existing Files:**
1. Go to **File Manager**
2. Click **"Upload Files"**
3. Select HTML, CSS, JS files
4. Files are uploaded instantly

**Option B - Create New Files:**
1. Click **"New File"** 
2. Enter filename (e.g., `about.html`)
3. Edit content in the built-in editor
4. Save changes

### Step 4: Preview Your Website (30 seconds)

1. Click **"Preview Website"**
2. See your live website in action
3. Test all links and features
4. Make sure everything looks great

### Step 5: Publish & Go Live (30 seconds)

1. Return to your website dashboard
2. Click **"Publish Website"**
3. Confirm publishing
4. **Your website is now LIVE!**

---

## Your Website is Live! Now What?

### Share Your Website
Your website is accessible at: **yourusername.turbohostmw.com**

Share this URL with:
- Friends and family
- Colleagues and clients
- Social media
- Email signature
- Resume/Portfolio

### Connect Your Own Domain

Want to use your domain? Follow these steps:

1. Go to **Website Settings** → **Custom Domain**
2. Enter your domain (e.g., mysite.com)
3. Follow DNS configuration instructions
4. Wait 24-48 hours for changes to propagate
5. Your domain is connected!

### Keep Content Fresh

- Update files regularly
- Publish changes immediately
- Keep backup of files locally
- Monitor your storage usage

---

## Common Tasks

### Uploading Multiple Files

1. Click **"File Manager"**
2. Click **"Upload Multiple"**
3. Select multiple files
4. **OR** drag files directly into manager
5. Files upload instantly

### Organizing Files

Best practice folder structure:
```
your-website/
├── index.html          (homepage)
├── about.html
├── contact.html
├── css/
│   ├── style.css
│   └── responsive.css
├── js/
│   ├── main.js
│   └── jquery.js
└── assets/
    ├── images/
    └── fonts/
```

### Making a Basic Website

**1. Create index.html:**
```html
<!DOCTYPE html>
<html>
<head>
    <title>My Website</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <h1>Welcome to My Website</h1>
    <p>This is my amazing website!</p>
    <script src="js/main.js"></script>
</body>
</html>
```

**2. Create css/style.css:**
```css
body {
    font-family: Arial, sans-serif;
    max-width: 1200px;
    margin: 0 auto;
    padding: 20px;
}
h1 { color: #333; }
```

**3. Upload both files**
**4. Publish website**
**5. Done!**

---

## Storage & Plans

### Free Plan
✓ 3 websites  
✓ 500 MB storage  
✓ Free subdomain  
✓ Basic editing  

**Perfect for:** Beginners, blogs, portfolios

### Premium Plan
✓ Unlimited websites  
✓ 50 GB storage  
✓ Custom domains  
✓ Priority support  
✓ Better resources  

**Perfect for:** Businesses, large projects

### Storage Tips

1. **Optimize Images**
   - Use JPEG for photos
   - Use PNG for graphics
   - Compress before uploading
   - Recommended tools: TinyPNG, ImageOptim

2. **Keep Code Clean**
   - Minify CSS and JavaScript
   - Remove unused files
   - Compress files when possible

3. **Monitor Usage**
   - Check dashboard regularly
   - Delete old/unused files
   - Download backups periodically

---

## Editing Files

### Using Our Web Editor

1. Go to **Editor** section
2. Select file from list
3. Make changes
4. Press **Ctrl+S** to save
5. Changes saved instantly

### Keyboard Shortcuts

| Shortcut | Action |
|----------|--------|
| Ctrl+S | Save file |
| Ctrl+Z | Undo |
| Ctrl+Y | Redo |
| Ctrl+F | Find |
| Ctrl+H | Replace |
| Ctrl+G | Go to line |

### File Types Supported

- **HTML** (.html, .htm)
- **CSS** (.css)
- **JavaScript** (.js)
- **JSON** (.json)
- **Text** (.txt)
- **And more!**

---

## Troubleshooting Quick Tips

### Website Not Showing

**Problem:** After publishing, website shows blank or error

**Solutions:**
1. ✓ Make sure you have `index.html` file
2. ✓ Refresh browser (Ctrl+F5)
3. ✓ Check file names are correct
4. ✓ Wait 2-3 minutes for publishing to complete
5. ✓ Check for JavaScript errors (browser console)

### Files Won't Upload

**Problem:** Getting upload error

**Solutions:**
1. ✓ Check file size (free plan: 50MB max per file)
2. ✓ Check file extension is supported
3. ✓ Check total storage available
4. ✓ Try smaller file
5. ✓ Try different browser

### Website is Slow

**Problem:** Website loads slowly

**Solutions:**
1. ✓ Optimize images (reduce size)
2. ✓ Remove unused files
3. ✓ Minimize CSS/JavaScript
4. ✓ Delete cached files
5. ✓ Upgrade to Premium for better resources

### Can't Login

**Problem:** Forgot password or can't access account

**Solutions:**
1. ✓ Click **"Forgot Password?"**
2. ✓ Enter your email
3. ✓ Check email for reset link
4. ✓ Create new password
5. ✓ Login with new password

---

## Security Best Practices

### Protect Your Account
1. **Strong Password** - Use mix of letters, numbers, symbols
2. **Don't Share Password** - Keep it private
3. **Enable 2FA** - Add extra security layer
4. **Logout When Done** - Especially on public computers

### Backup Your Files
1. **Download Regularly**
   - Use "Export as ZIP" to backup all files
   - Save to your computer
   - Keep multiple backups

2. **Test Backups**
   - Extract ZIP occasionally
   - Verify files are complete
   - Store in safe location

### Website Security
1. **Use HTTPS** - For custom domains
2. **Keep Software Updated** - Update frameworks
3. **Regular Backups** - As mentioned above
4. **Monitor Activity** - Check access logs

---

## Next Steps to Level Up

### 1. Add Navigation
```html
<nav>
  <a href="index.html">Home</a>
  <a href="about.html">About</a>
  <a href="contact.html">Contact</a>
</nav>
```

### 2. Style with CSS
```css
nav { 
  background: #333; 
}
nav a { 
  color: white; 
  padding: 10px; 
}
```

### 3. Add Interactivity with JavaScript
```javascript
document.getElementById('btn').addEventListener('click', function() {
  alert('Button clicked!');
});
```

### 4. Connect a Domain
- Buy domain from registrar
- Configure DNS records
- Link to TurboHostMw
- Verify ownership

### 5. Upgrade to Premium
- Get unlimited websites
- Access 50GB storage
- Connect multiple domains
- Get priority support

---

## Useful Resources

### Learn Web Development
- **HTML Basics:** Learn structure
- **CSS Tutorial:** Master styling
- **JavaScript Guide:** Add interactivity
- **Responsive Design:** Mobile-friendly sites

### Free Tools
- **TinyPNG:** Compress images
- **FontAwesome:** Icons library
- **Google Fonts:** Free fonts
- **Bootstrap:** CSS framework

### Templates
- Browse templates in create wizard
- Customize to match your brand
- Use as starting point

---

## Getting Help

### Need Support?

**Email:** phukal@mau.adventist.org  
**Response Time:** 24-48 hours  
**Include:**
- Your email/account
- What you were doing
- Error messages
- Browser you're using

### Knowledge Base
Visit our help center for:
- Tutorials
- FAQs
- Guides
- Troubleshooting

---

## Quick Reference

### Free Plan Limits
- Max websites: 3
- Storage: 500 MB
- Upload limit: 50 MB per file
- Support: Email

### Premium Plan Includes
- Max websites: Unlimited
- Storage: 50 GB
- Upload limit: 1 GB per file
- Support: Priority email
- Custom domains: Yes

### File Manager Shortcuts
- Upload: Click upload button
- Download: Click file → Download
- Delete: Select file → Delete
- Create: Click "New File"

### Dashboard Quick Links
- My Websites: `/dashboard/websites`
- Profile: `/profile`
- Notifications: `/dashboard/notifications`
- File Manager: `/dashboard/websites/files`

---

## Congrats! You're Ready

You now know enough to:
✓ Create websites  
✓ Upload files  
✓ Edit content  
✓ Publish online  
✓ Manage your site  

**Next:** Start creating and have fun!

---

## Questions?

📧 **Email:** phukal@mau.adventist.org  
🌐 **Website:** www.turbohostmw.com  
💬 **Chat:** Available on our website

---

**TurboHostMw - Make Your Website Happen!**  
*Last Updated: January 2026*
