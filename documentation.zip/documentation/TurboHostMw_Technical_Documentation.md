# TurboHostMw - Technical Architecture Documentation

## System Overview

TurboHostMw is a web hosting platform built with PHP using a custom MVC framework. It allows users to create, manage, and publish websites with file management, editing, and storage capabilities.

---

## Technology Stack

### Backend
- **Language:** PHP 7.4+
- **Pattern:** MVC (Model-View-Controller)
- **Database:** MySQL/MariaDB
- **Architecture:** Custom PHP Framework (no external frameworks)

### Frontend
- **HTML5, CSS3, JavaScript**
- **Responsive Design**
- **File Management UI**
- **Code Editor Integration**

### Core Components
- Custom Router
- Custom ORM/Model Layer
- View Template Engine
- Authentication Service
- Database Abstraction Layer

---

## Directory Structure

```
TurboHostMw/
├── app/
│   ├── Config/              # Configuration files
│   │   ├── app.php         # Main app config
│   │   ├── constants.php   # Global constants
│   │   ├── database.php    # DB config
│   │   ├── mail.php        # Email config
│   │   └── routes.php      # Route definitions
│   ├── Controllers/         # HTTP request handlers
│   ├── Core/               # Framework core classes
│   │   ├── App.php         # Main application class
│   │   ├── Router.php      # URL routing
│   │   ├── Controller.php  # Base controller
│   │   ├── Model.php       # Base model
│   │   ├── Database.php    # DB connection
│   │   ├── View.php        # Template renderer
│   │   ├── Session.php     # Session management
│   │   ├── Csrf.php        # CSRF protection
│   │   ├── Validator.php   # Input validation
│   │   └── Router.php      # URL routing
│   ├── Models/             # Data models & repositories
│   ├── Services/           # Business logic services
│   ├── Middleware/         # Request middleware
│   ├── Helpers/            # Utility functions
│   └── Views/              # View templates
├── public/
│   ├── index.php           # Entry point
│   ├── sites/              # Published websites
│   ├── templates/          # Website templates
│   └── uploads/            # User uploads
├── storage/
│   ├── backups/            # Backup files
│   ├── cache/              # Cache files
│   ├── logs/               # Application logs
│   ├── projects/           # Project files
│   └── sessions/           # Session data
├── database/
│   ├── schema.sql          # Database schema
│   ├── migrations/         # Database migrations
│   └── seeders/            # Test data seeders
└── vendor/                 # Composer dependencies
```

---

## Core Architecture

### Application Flow

```
HTTP Request
    ↓
public/index.php (entry point)
    ↓
App.php (bootstraps framework)
    ↓
Router.php (matches URL to route)
    ↓
Controller (processes request)
    ↓
Service/Model (business logic)
    ↓
View (renders response)
    ↓
HTTP Response
```

### Key Classes

#### Core/App.php
- Initializes the application
- Loads configuration
- Sets up error handling
- Manages dependencies

#### Core/Router.php
- Routes HTTP requests to controllers
- Supports GET, POST, PUT, DELETE
- Pattern matching for dynamic routes
- CSRF token validation

#### Core/Controller.php
- Base class for all controllers
- Provides request/response handling
- View rendering
- Input validation

#### Core/Model.php
- Base class for models
- Database query builder
- CRUD operations
- Data relationships

#### Core/Database.php
- PDO-based database connection
- Query execution
- Transaction support
- Connection pooling

### Authentication & Authorization

**AuthService.php:**
- User login/logout
- Session management
- Password hashing (bcrypt)
- Two-factor authentication support
- Admin role checking

**Authentication Flow:**
1. User submits credentials
2. Validated against user table
3. Password verified with hash
4. Session created on success
5. Session ID stored in cookie
6. User identified on subsequent requests

### File Management System

**FileManagerController.php:**
- File upload/download
- Directory navigation
- File operations (create, delete, move, rename)
- ZIP import/export
- Storage quota enforcement

**ProjectStorageService.php:**
- Tracks storage usage per user
- Enforces storage limits
- Calculates file sizes
- Manages storage policies

**Storage Structure:**
```
storage/projects/
├── {user_id}/
│   └── {website_id}/
│       ├── index.html
│       ├── css/
│       ├── js/
│       └── assets/
```

### Website Publishing System

**PublishingService.php:**
- Handles website publication
- Validates website files
- Creates public version
- Generates public URLs

**Website States:**
- Draft: Private, only accessible to owner
- Published: Live, accessible publicly
- Archived: Inactive, no longer served
- Expired: Free plan websites after expiration

**Published Site Access:**
- Subdomain: `username.turbohostmw.com`
- Custom Domain: `yourdomain.com`
- Files served from `public/sites/{website_id}/`

### Payment & Subscription System

**PaymentController.php:**
- Payment processing
- Plan upgrades
- Subscription management
- Payment gateway integration (PayChangu)

**PlanService.php:**
- Free plan: 3 websites, 500MB storage
- Premium plan: Unlimited websites, 50GB storage
- Plan limits enforcement
- Storage calculations

### Notification System

**NotificationService.php:**
- System notifications
- User notifications
- Notification preferences
- Notification polling

**Notification Types:**
- Security alerts (login, password changes)
- Payment updates
- Website events
- System maintenance

### Email System

**MailerService.php:**
- SMTP configuration
- Email template rendering
- Notification sending
- Verification emails
- Password reset emails

**EmailVerificationService.php:**
- Email verification tokens
- Token expiration
- Verification workflow
- Retry limits

---

## Database Schema

### Users Table
```sql
CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    email VARCHAR(255) UNIQUE NOT NULL,
    username VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    name VARCHAR(255),
    two_factor_enabled BOOLEAN DEFAULT FALSE,
    two_factor_secret VARCHAR(255),
    email_verified_at TIMESTAMP NULL,
    plan VARCHAR(50) DEFAULT 'free',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
```

### Websites Table
```sql
CREATE TABLE websites (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    website_name VARCHAR(255) NOT NULL,
    slug VARCHAR(255) UNIQUE,
    subdomain VARCHAR(255) UNIQUE,
    custom_domain VARCHAR(255),
    storage_used BIGINT DEFAULT 0,
    bandwidth_used BIGINT DEFAULT 0,
    status VARCHAR(50) DEFAULT 'draft',
    expires_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
```

### Payments Table
```sql
CREATE TABLE payments (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    amount DECIMAL(10, 2),
    currency VARCHAR(3),
    payment_method VARCHAR(50),
    status VARCHAR(50),
    transaction_id VARCHAR(255) UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
```

---

## Key Services

### AuthService
- Handles user authentication
- Manages sessions
- Provides login/logout/register
- Supports two-factor authentication
- Admin access control

### PlanService
- Defines pricing plans
- Calculates storage limits
- Manages plan restrictions
- Handles plan upgrades
- Free plan limits: 3 websites, 500MB storage
- Premium plan: Unlimited, 50GB storage

### PublishingService
- Validates website files
- Creates public versions
- Manages URLs (subdomains & custom domains)
- Handles unpublishing
- Manages file permissions

### MailerService
- Sends transactional emails
- Template rendering
- SMTP configuration
- Retry logic
- Error handling

### NotificationManager
- In-app notifications
- Email notifications
- Notification preferences
- Real-time polling support

### LegalService
- Policy management
- Version tracking
- Policy acceptance tracking
- Audit logging

---

## Controllers

### AuthController
- User registration
- User login
- Password reset
- Two-factor authentication
- Email verification

### DashboardController
- Dashboard display
- User profile
- Profile updates
- Password changes
- Email management

### WebsiteController
- List user websites
- Create websites
- Edit websites
- Delete websites
- Website settings

### FileManagerController
- File upload
- File download
- Directory navigation
- File operations (create, delete, move)
- ZIP import/export

### EditorController
- File editing
- Code syntax highlighting
- File saving
- Auto-completion support

### PreviewController
- Live preview rendering
- File preview
- Website preview

### PublishController
- Website publishing
- Website unpublishing
- Publishing validation

### PaymentController
- Payment processing
- Payment callbacks
- Subscription management
- Invoice generation

### AdminController
- Admin dashboard
- User management
- Website management
- Analytics and reports
- Settings management
- Media library management

### NotificationController
- Notification polling
- Notification display
- Notification preferences

---

## Security Features

### CSRF Protection
- CSRF tokens generated for forms
- Token validation on POST requests
- Token refresh on each request
- Stored in session

### Password Security
- bcrypt hashing (cost factor 12)
- Minimum 8 characters required
- Strong password requirements
- Password change history

### Session Management
- Secure session cookies
- Session expiration (24 hours default)
- Session fixation protection
- Simultaneous session limiting

### Two-Factor Authentication (2FA)
- TOTP support (RFC 6238)
- QR code generation
- Backup codes
- Device enrollment

### Input Validation
- Server-side validation required
- Validator class with rules
- Sanitization of user input
- Protection against injection attacks

### Authorization
- Role-based access control (User/Admin)
- Resource ownership validation
- Permission checking on each action
- Admin-only sections

---

## Routing

Routes are defined in `app/Config/routes.php`:

```php
'GET' => [
    '/dashboard' => [DashboardController::class, 'index'],
    '/dashboard/websites' => [WebsiteController::class, 'index'],
    // ... more routes
],
'POST' => [
    '/login' => [AuthController::class, 'login'],
    '/dashboard/websites' => [WebsiteController::class, 'store'],
    // ... more routes
]
```

**Route Features:**
- Dynamic segments: `/websites/{id}`
- Query parameters: `?sort=date`
- Named routes support
- Route groups (implicit)

---

## Request/Response Cycle

### Request Processing
1. HTTP request received
2. Router matches URL pattern
3. Controller action called
4. Input validation
5. Service layer processes business logic
6. Database queries executed
7. Response prepared

### Response Types
- **HTML View:** Rendered template
- **JSON:** API response
- **Redirect:** HTTP redirect
- **File Download:** Binary file
- **Error Page:** Error template

---

## Error Handling

### Error Handling Strategy
- Try-catch blocks in key areas
- Custom error handler registered
- Error logging to files
- User-friendly error pages
- Development/production modes

### Error Logging
- Logs stored in `storage/logs/`
- Log files by date
- Error level tracking
- Stack traces in logs

---

## Performance Considerations

### Optimization Techniques
- Database query optimization
- N+1 query prevention
- Lazy loading for relationships
- Template caching
- Static file caching headers
- Compression support

### Scalability
- Stateless design (can scale horizontally)
- Database connection pooling
- File storage on server disk (or cloud ready)
- Session storage flexible (files, database, Redis)

---

## Deployment

### Requirements
- PHP 7.4 or higher
- MySQL 5.7+ or MariaDB 10.2+
- Apache with mod_rewrite (for URL rewriting)
- OR Nginx with proper routing

### Installation Steps
1. Clone repository
2. Copy `.env.example` to `.env`
3. Configure database connection
4. Run database migrations
5. Set storage permissions
6. Configure web server
7. Set up SSL certificate
8. Configure domain/subdomains

### Environment Configuration
- `.env` file for configuration
- Database credentials
- Mail settings
- API keys
- Debug mode

---

## Development Workflow

### Setting Up Development Environment
```bash
# Clone repository
git clone [repo]

# Install dependencies (if using Composer)
composer install

# Set environment variables
cp .env.example .env
# Edit .env with local settings

# Create database
mysql -u root -p < database/schema.sql

# Set permissions
chmod -R 755 storage/
chmod -R 755 public/

# Start development server
php -S localhost:8000 -t public/
```

### Common Development Tasks
- Add new route in `routes.php`
- Create controller in `Controllers/`
- Create model in `Models/`
- Create view templates in `Views/`
- Add business logic to `Services/`

### Testing
- Manual testing via browser
- API testing tools (Postman)
- Database verification
- File system checks

---

## API Endpoints

### Authentication
- `POST /login` - User login
- `POST /register` - User registration
- `POST /logout` - User logout
- `POST /forgot-password` - Password reset request
- `POST /reset-password` - Password reset confirm

### Dashboard
- `GET /dashboard` - Dashboard view
- `GET /profile` - User profile
- `POST /profile/update` - Update profile
- `POST /profile/change-password` - Change password

### Websites
- `GET /dashboard/websites` - List websites
- `GET /dashboard/websites/create` - Create form
- `POST /dashboard/websites` - Create website
- `GET /dashboard/websites/edit` - Edit form
- `POST /dashboard/websites/update` - Update website
- `POST /dashboard/websites/delete` - Delete website

### File Manager
- `GET /dashboard/websites/files` - File list
- `POST /dashboard/websites/files/upload` - Upload file
- `POST /dashboard/websites/files/create-file` - Create file
- `POST /dashboard/websites/files/create-folder` - Create folder
- `POST /dashboard/websites/files/delete` - Delete file/folder
- `POST /dashboard/websites/files/move` - Move file
- `GET /dashboard/websites/files/download` - Download file
- `GET /dashboard/websites/files/export` - Export as ZIP
- `POST /dashboard/websites/files/import` - Import ZIP

### Editor
- `GET /dashboard/websites/editor` - Edit page
- `POST /dashboard/websites/editor/save` - Save file

### Publishing
- `POST /dashboard/websites/publish` - Publish website
- `POST /dashboard/websites/unpublish` - Unpublish website

### Payments
- `POST /payments/paychangu/premium` - Initiate premium checkout
- `GET /payments/paychangu/callback` - Payment callback
- `GET /payments/paychangu/return` - Payment return

### Admin
- `GET /admin` - Admin dashboard
- `GET /admin/users` - User management
- `GET /admin/websites` - Website management
- `GET /admin/payments` - Payment management
- `GET /admin/settings` - Settings
- `POST /admin/settings` - Save settings

---

## Troubleshooting

### Common Issues

**Database Connection Error**
- Check database credentials in `.env`
- Verify database server is running
- Check user permissions

**File Upload Fails**
- Check storage folder permissions
- Verify disk space available
- Check PHP upload limits (php.ini)

**Page Not Found (404)**
- Check routes configuration
- Verify URL pattern matches
- Check .htaccess for rewrites

**Session Issues**
- Check PHP session directory permissions
- Verify session cookie settings
- Clear browser cookies

**Email Not Sending**
- Check SMTP configuration
- Verify firewall rules
- Check email logs

---

## Future Enhancements

Potential improvements and features:
- Database caching layer (Redis)
- CDN integration for static files
- Advanced analytics
- Collaboration features
- Version control for files
- Advanced security features
- API rate limiting
- Webhook support
- Template marketplace
- Domain marketplace

---

## License & Support

For technical support and questions, contact the development team.

**Last Updated:** January 2026
**Version:** 1.0
