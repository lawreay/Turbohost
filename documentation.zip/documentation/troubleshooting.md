# Troubleshooting & Common Fixes

1. 500 or blank pages
- Check PHP error logs and `app/Core/Router` route mapping. Ensure `app/Config/app.php` returns valid `base_url`.

2. Mail not sending
- Verify SMTP settings in platform settings and `app/Config/mail.php`. Test using `MailerService` in a PHP one-liner.

3. Publish fails with permission error
- Ensure PHP process user has write permission to `public/sites` and `public`.

4. Sitemap not found
- Confirm `public/sitemap.xml` exists; `SitemapGenerator::writeToFile()` runs on publish and at bootstrap.

5. Missing files after publish
- Check `PublishingService` whitelist and ensure file types are permitted.

6. Notification polling returns empty
- Inspect `api/notifications/poll` route and ensure AJAX uses correct base URL.

Maintenance tips:
- Regularly prune `storage/cache` and rotate logs in `storage/logs`.

Maintainer:
- Lawrence Phuka — adminphukal@mau.adventist.org