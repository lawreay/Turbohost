# Admin Media Documentation

This section covers the admin media management area.

Topics:
- Media upload and deletion
- File storage and retention
- Access control for media assets

Maintainer:
- Lawrence Phuka — adminphukal@mau.adventist.org