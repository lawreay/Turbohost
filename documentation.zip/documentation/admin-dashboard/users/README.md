# Admin Users Documentation

This section covers admin user management.

Topics:
- User listing and search
- Role assignment and plan changes
- User deletion and account management

Maintainer:
- Lawrence Phuka — adminphukal@mau.adventist.org