# Admin Legal Documentation

This section covers legal content and policy management.

Topics:
- Legal pages (privacy, terms)
- Policy versioning and publishing
- Policy acceptance tracking

Maintainer:
- Lawrence Phuka — adminphukal@mau.adventist.org