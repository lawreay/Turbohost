# Admin Reports Documentation

This section covers admin reporting and analytics.

Topics:
- System usage overview
- Website and payment reports
- Admin dashboard report generation

Maintainer:
- Lawrence Phuka — adminphukal@mau.adventist.org