# Admin Notifications Documentation

This section covers admin-side notification management.

Topics:
- Broadcast notifications
- Email delivery options
- Notification templates and user targeting

Maintainer:
- Lawrence Phuka — adminphukal@mau.adventist.org