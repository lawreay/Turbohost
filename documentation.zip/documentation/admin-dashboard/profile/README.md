# Admin Profile Documentation

This section covers admin profile operations.

Topics:
- Profile view and update
- Password changes
- Email update confirmation
- Account deactivation flow

Maintainer:
- Lawrence Phuka — adminphukal@mau.adventist.org