# Admin Dashboard Documentation

This folder contains documentation for the admin dashboard and all related menu areas.

Structure:
- `websites/`
- `media/`
- `users/`
- `payments/`
- `reports/`
- `notifications/`
- `profile/`
- `legal/`

Each subfolder contains technical details for that admin menu area.

Maintainer:
- Lawrence Phuka — adminphukal@mau.adventist.org