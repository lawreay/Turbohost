# Models Reference

Location: `app/Models`

Primary models:
- `User` — platform users
- `Website` — website projects (status, slug, storage usage)
- `Notification` — in-app notifications
- `Setting` / `PlatformSetting` — persisted platform configuration
- `Subscription` (where present) — user subscriptions
- `Payment` — payment records
- `LegalPolicy` / `LegalPolicyVersion` — legal text and versions

Notes:
- Models extend `app/Core/Model` which depends on `app/Core/Database` for PDO.
- Add indices to database migrations for common query columns (`user_id`, `status`, `created_at`).

Maintainer:
- Lawrence Phuka — adminphukal@mau.adventist.org