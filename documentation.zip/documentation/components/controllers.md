# Controllers Reference

Location: `app/Controllers`

List of controllers and responsibilities:
- `AdminController.php` — admin UI and management (users, websites, settings)
- `AuthController.php` — login, registration, password reset, two-factor
- `DashboardController.php` — user dashboard and profile
- `EditorController.php` — code editor for project files
- `FileManagerController.php` — file operations, upload, import/export
- `HomeController.php` — legacy or simple home handlers if present
- `LegalController.php` — privacy/terms and policy versions
- `MarketingController.php` — public marketing pages and contact
- `NotificationController.php` — AJAX endpoints for polling and mark-read
- `PaymentController.php` — payment callbacks and returns
- `PreviewController.php` — previewing draft files
- `PublishController.php` — publish/unpublish static sites
- `SitemapController.php` — serves sitemap XML
- `WebsiteController.php` — CRUD for website projects

Developer guidance:
- Controllers extend `app/Core/Controller` and call `$this->view()` to render templates.
- Use `Csrf::validate()` for POST handlers and `Session::flash()` for messages.

Maintainer:
- Lawrence Phuka — adminphukal@mau.adventist.org