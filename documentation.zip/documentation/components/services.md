# Services Reference

Location: `app/Services`

Primary services:
- `AuthService` — authentication helpers
- `MailerService` — wraps PHPMailer for outgoing mail
- `NotificationManager` & `NotificationService` — orchestrate in-app and email notifications
- `PublishingService` — publishes draft storage to `public/sites`
- `ProjectStorageService` — file storage helpers for draft projects
- `PublicSiteUrlService` — canonical URL builders for published sites
- `ProjectArchiveService` — export/archive utilities
- `PlanService` — plan limits and features
- `SitemapGenerator` — sitemap XML builder and writer

Developer guidance:
- Services encapsulate side-effectful operations; prefer adding new logic here rather than controllers.
- For scalability, convert long-running operations to background workers.

Maintainer:
- Lawrence Phuka — adminphukal@mau.adventist.org