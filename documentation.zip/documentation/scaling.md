# Scaling & Operational Recommendations

Application scaling:
- Separate static file serving: host `public/sites` and `public/assets` on a CDN or separate Nginx/Apache optimized static host.
- Convert publish/unpublish and email broadcast tasks to background workers (Redis queue + worker processes).
- Use read-replicas for database reads (dashboard list endpoints) and a single writer for writes.
- Add caching layer (Redis) for frequently-read platform settings and counts.

Security & reliability:
- Harden `.env` and config; remove credentials from repo.
- Use rate limiting on public endpoints (contact form, register).
- Add monitoring and alerting (errors, disk usage, queue backlog).

Maintenance:
- Automate backups of DB and `public/sites`.
- Implement health checks for storage and SMTP endpoints.

Maintainer:
- Lawrence Phuka — adminphukal@mau.adventist.org