# Architecture

High level:
- PHP 8+ monolithic MVC-style app (custom lightweight framework) located in `app/`.
- Public front controller: `public/index.php`.
- Router: `app/Core/Router.php` maps routes to controller actions using `app/Config/routes.php`.
- Controllers live in `app/Controllers/` and return views via `app/Core/View.php` and `app/Core/Controller.php` helpers.
- Models extend `app/Core/Model.php` and use `app/Core/Database.php` for PDO connections.
- Services in `app/Services/` encapsulate domain logic (publishing, notifications, mail, storage).
- Public static sites are published under `public/sites/{projectId}/{slug}/` by `PublishingService`.
- Static assets: `public/assets/` and upload storage under `storage/`.

Key data flows:
- User requests -> Router -> Controller -> Model/Service -> View or Response
- Publish flow: `WebsiteController`/`PublishController` -> `PublishingService` -> public files -> `SitemapGenerator` update

Security and operational considerations:
- CSRF checks in controllers via `app/Core/Csrf` on state-changing POSTs.
- Sessions via `app/Core/Session`.
- Environment config via `.env` and `app/Config/constants.php`.

Maintainer:
- Lawrence Phuka — adminphukal@mau.adventist.org — +265993147700