# Feature: Contact Form

Purpose:
- Public contact page for customer inquiries.

Primary components:
- Controller: `MarketingController::sendContact`
- View: `app/Views/marketing/contact.php`
- Service: `MailerService` (sends to admin email)

Behavior:
- Validates CSRF and required fields (name, email, message).
- Uses platform setting `admin_login_notification_email` or `mail_from_address` as recipient.
- Constructs HTML and plain text versions and sends via `MailerService`.

Improvements:
- Add CAPTCHA or rate-limiting to avoid abuse.
- Persist inbound messages to a `messages` table for audit and response workflow.
- Add retry/backoff for failed sends; surface failure reason to admins.

Maintainer:
- Lawrence Phuka — adminphukal@mau.adventist.org