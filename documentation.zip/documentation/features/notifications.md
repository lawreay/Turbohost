# Feature: Notifications

Purpose:
- In-app notifications for user events (publish, updates, admin messages).

Primary components:
- Controller: `NotificationController` (`poll`, `markRead` endpoints)
- Models: `Notification` persistence model
- Services: `NotificationManager`, `NotificationService`
- Frontend: polling in `public/assets/js/main.js` and UI in dashboard layout

Flow:
- Server-side triggers (`NotificationManager::sendUserNotification`) insert notification rows and optionally queue email via `NotificationService`.
- Client JS polls `/api/notifications/poll` to display unread count and items.
- Clicking a notification calls `/api/notifications/mark-read` to mark it read.

Scaling & improvements:
- Replace polling with WebSocket or server-sent events to reduce load.
- Add database indices on `user_id` and `created_at` for query performance.
- Batch notifications for high-volume events and rate-limit admin broadcasts.

Failure modes & debugging:
- Polling returns errors: inspect `NotificationController::poll` and server logs.
- Missing email delivery: verify `MailerService` config in `app/Config/mail.php` and platform settings.

Maintainer:
- Lawrence Phuka — adminphukal@mau.adventist.org