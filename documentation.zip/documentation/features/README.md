# Features — High Level

This folder contains feature-specific technical documentation. Each feature document explains:
- Purpose and UX surface
- Related controllers, services, and models
- Data flows and storage
- Hooks for scaling and typical failure modes

Features included:
- Publishing (static site deploy)
- Notifications
- Admin broadcast
- Contact form
- Sitemap generation

Maintainer:
- Lawrence Phuka — adminphukal@mau.adventist.org