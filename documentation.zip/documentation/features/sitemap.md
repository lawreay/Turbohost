# Feature: Sitemap Generation

Purpose:
- Provide a machine-readable `sitemap.xml` for marketing pages and published client sites.

Primary components:
- Service: `SitemapGenerator` (generates and writes `public/sitemap.xml`)
- Controller: `SitemapController::show` (returns XML dynamically if requested)
- Hook points: invoked after publish/unpublish/delete and at bootstrap to ensure file exists

Behavior & caching:
- `SitemapGenerator::writeToFile()` writes a static `public/sitemap.xml` so webserver can serve it directly.
- `.htaccess` contains a rule to prefer `public/sitemap.xml` if present.

Scaling & SEO suggestions:
- Include `lastmod` per page when available and priority tags according to importance.
- Optionally provide multi-sitemap index for very large installations.

Maintainer:
- Lawrence Phuka — adminphukal@mau.adventist.org