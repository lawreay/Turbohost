# Feature: Admin Broadcast & Email

Purpose:
- Admins can broadcast notifications to users and optionally send email.

Primary components:
- Controller: `AdminController::broadcastNotifications`
- View: Admin notifications UI with email checkbox
- Services: `NotificationManager`, `MailerService`

Notes:
- Email sending uses `MailerService` (PHPMailer). Admins must configure SMTP settings in platform settings.
- To scale, move email sending into background jobs with retry logic and rate-limiting. Use transactional queue to ensure notifications and emails are consistent.

Common issues:
- SMTP credential failures -> check settings page and logs.
- Large recipient lists -> use batching and exponential backoff, or integrate with an email provider (SendGrid, Mailgun).

Maintainer:
- Lawrence Phuka — adminphukal@mau.adventist.org