# Feature: Publishing (Static site deployment)

Purpose:
- Convert a draft project in storage into a static site under `public/sites/{id}/{slug}/`.

Primary components:
- Controller: `PublishController` (publish, unpublish)
- Service: `PublishingService` (file copy, whitelist by extension)
- URL helper: `PublicSiteUrlService`
- Model: `Website` (status updates)

Flow:
1. User triggers publish via dashboard UI -> POST `/dashboard/websites/publish`.
2. `PublishController::publish()` validates CSRF and calls `PublishingService::publish()`.
3. `PublishingService` copies allowed files to the public site path. It checks `index.html` exists and enforces file type whitelist.
4. `Website::updateStatus()` sets `status = 'published'`.
5. `SitemapGenerator` is invoked to refresh `public/sitemap.xml`.
6. Notifications are sent via `NotificationManager`.

Scaling & reliability:
- Use a background job queue for large sites (currently synchronous). Move `PublishingService` copy operations to a worker to avoid request timeouts.
- Use checksums or timestamp-based delta copy to avoid full replacements for minor edits.
- Ensure `public/sites` storage is on fast disk or network storage optimized for static serving.

Failure modes & debugging:
- Missing `index.html`: publishing throws. Verify draft storage path and file exists.
- Permission errors when creating public folders: check `PUBLIC_PATH` and server user.
- Partial copy: ensure atomic replace behavior (current `PublishingService` replaces directory then copies files).

Maintainer:
- Lawrence Phuka — adminphukal@mau.adventist.org