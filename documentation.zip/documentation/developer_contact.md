# Developer / Maintainer Contact

Primary maintainer:
- Name: Lawrence Phuka
- Role: Admin
- Email: adminphukal@mau.adventist.org
- Phone: +265993147700
- Country: Malawi
- Website: lawreay.lovestoblog.org

Please contact for:
- Access and admin questions
- Deployment and environment secrets
- Feature clarifications and roadmap

Security: Do not place secrets in repository files. Use environment variables or a secrets manager.