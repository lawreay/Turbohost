# TurboHostMw PHP/SQL Hosting Audit

## Overview
This audit maps the current TurboHostMw architecture for website publishing and identifies what is required to support PHP and SQL hosting.

The current app is a static site builder/publisher. It manages draft project files, previews, and publishes static sites to `public/sites/{projectId}/{slug}`.

---

## Current architecture map

### Entry point and routing
- `public/index.php` bootstraps `App\Core\App`.
- `App\Core\App::run()` loads config and routes, starts session, and dispatches via `App\Core\Router`.
- `public/.htaccess` rewrites non-file requests to `public/index.php`.

### Draft storage and upload
- Draft files are stored in `storage/projects/{userId}/{slug}`.
- `App\Services\ProjectStorageService` handles:
  - project path construction
  - safe path normalization
  - directory creation
  - file listing
  - file read/write operations
- `App\Services\UploadValidationService` controls allowed uploaded file types.

### Preview flow
- `app/Controllers/PreviewController::show()` displays the preview wrapper.
- `app/Controllers/PreviewController::file()` serves draft project files after validation.
- HTML assets are rewritten to route through `/dashboard/websites/preview/file`.
- No PHP execution is performed in preview mode.

### Publishing flow
- `app/Controllers/PublishController` publishes and unpublishes sites.
- `app/Services\PublishingService` copies allowed files from draft storage to `public/sites/{projectId}/{slug}`.
- Published sites are assumed to be static.
- `app/Services\PublicSiteUrlService` generates public URL paths.

### Project and website data
- `app/Models\Website` manages website records, including:
  - user-owned project queries
  - create/update/delete operations
  - active website count
  - slug existence checks
  - free hosting expiry via `expires_at`
- `app/Services\PlanService` reads hosting plan settings and limits.

---

## What currently blocks PHP hosting

### Validation and file restrictions
- `app/Services\UploadValidationService.php`
  - blocks `.php`, `.phtml`, `.phar`, `.cgi`, and other executable files.
- `app/Services\ProjectArchiveService.php`
  - blocks the same extensions when importing ZIP archives.
- `app/Services\PublishingService.php`
  - only publishes static extensions.
  - requires `index.html` in draft.

### Preview limitations
- `PreviewController::file()` reads files and sends them as text or binary.
- It does not execute `.php` files or handle PHP response generation.

### Storage and project model
- Starter and created files are primarily static HTML/text templates.
- Project metadata does not include site execution mode or database mapping.

---

## What is required for PHP hosting

### 1. Allow PHP content in the draft pipeline
- Update `UploadValidationService` to permit PHP files if the site is allowed.
- Update `ProjectArchiveService` to accept `.php` files in uploads and ZIP imports.
- Update any file creation or editing validation to allow PHP extensions safely.

### 2. Modify publish logic for dynamic sites
- Remove the hard dependency on `index.html` for publication.
- Copy `.php` and related dynamic files to the public site directory.
- Ensure `public/.htaccess` or server config supports `index.php` as the default document.

### 3. Add PHP preview support
- Create a separate preview execution route for PHP pages.
- Avoid interpreting user PHP in the control panel runtime.
- If previews must execute PHP, do so with a sandboxed process or separate runtime.

### 4. Separate runtime path from the main app
- Do not expose `app/` or `storage/` contents through published PHP sites.
- Serve published PHP from `public/sites/...` only.
- Ensure site execution cannot access the admin app or other users' files.

---

## What is required for SQL hosting

### 1. Database provisioning model
- Decide on site-specific database architecture:
  - per-site SQLite database files, or
  - per-site MySQL database/user, or
  - shared database with table prefixing.
- Implement database creation and credentials management.

### 2. Site database configuration
- Provide a secure way to inject DB credentials into hosted PHP sites.
- Consider environment files or runtime config that is isolated per site.

### 3. SQL import/export and storage
- Add support for `.sql` import into the site database.
- Add site-level database export if needed.
- Track and limit SQL import sizes and user resource usage.

### 4. Security and isolation
- Prevent user PHP from accessing platform internals.
- Prevent SQL injection across site boundaries.
- Isolate database access per site or per user.

---

## Recommended implementation path

1. Define hosting modes
   - static-only
   - dynamic PHP hosting
   - PHP + SQL hosting

2. Extend the project model
   - add `hosting_type`, `database_type`, or `site_mode` to `websites` if needed
   - store site database credentials or config references

3. Adjust validation and publish services
   - allow `.php` in approved site types
   - copy PHP files on publish
   - preserve safe filename/path handling

4. Implement execution support
   - if using Apache, publish PHP files into `public/sites/...`
   - if using sandboxed preview, build a separate preview/execution mechanism

5. Build DB provisioning
   - create a service for database creation and cleanup
   - support credentials injection for hosted sites

6. Harden security
   - isolate published site file directories
   - ensure request routing cannot escape site roots
   - restrict file operations to user-owned projects only

---

## Key files involved

- `public/index.php`
- `public/.htaccess`
- `app/Core/App.php`
- `app/Core/Router.php`
- `app/Services/ProjectStorageService.php`
- `app/Services/PublishingService.php`
- `app/Services/UploadValidationService.php`
- `app/Services/ProjectArchiveService.php`
- `app/Controllers/PreviewController.php`
- `app/Controllers/PublishController.php`
- `app/Models/Website.php`
- `app/Services/PlanService.php`
- `app/Services/PublicSiteUrlService.php`

---

## Conclusion
TurboHostMw today is a static website host. Supporting PHP and SQL hosting will require:
- a new dynamic hosting layer,
- changed validation and publish behavior,
- execution/runtime support for PHP,
- and database provisioning plus strong isolation.

This document should serve as the implementation map for the next phase.
