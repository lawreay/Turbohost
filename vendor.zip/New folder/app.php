<?php
/**
 * Application runtime configuration.
 */

require_once __DIR__ . '/constants.php';

$timezone = (string) env('APP_TIMEZONE', 'Africa/Blantyre');
date_default_timezone_set($timezone);

return [
    'name' => (string) env('APP_NAME', 'TurboHostMw'),
    'environment' => (string) env('APP_ENV', 'production'),
    'debug' => filter_var(env('APP_DEBUG', false), FILTER_VALIDATE_BOOLEAN),
    'base_url' => rtrim((string) env('APP_URL', 'http://localhost/TurboHostMw/public'), '/'),
    'timezone' => $timezone,
    'paths' => [
        'root' => ROOT_PATH,
        'app' => APP_PATH,
        'public' => PUBLIC_PATH,
        'storage' => STORAGE_PATH,
        'uploads' => UPLOAD_PATH,
        'website_uploads' => WEBSITE_UPLOAD_PATH,
    ],
    'storage' => [
        'free_plan_bytes' => FREE_PLAN_STORAGE_LIMIT,
        'premium_plan_bytes' => null,
        'default_upload_file_bytes' => DEFAULT_UPLOAD_FILE_LIMIT,
    ],
];
