<?php

namespace App\Controllers;

use App\Core\Controller;
use App\Services\AuthService;
use App\Services\NotificationManager;

/**
 * Handles lightweight AJAX polling and notification status endpoints.
 */
class NotificationController extends Controller
{
    public function poll(): void
    {
        if (!AuthService::check()) {
            http_response_code(401);
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode(['error' => 'Unauthorized']);
            return;
        }

        $userId = AuthService::id();
        $manager = new NotificationManager($this->config);
        $latestNotifications = $manager->latestForUser($userId, 10);
        $unreadCount = $manager->unreadCount($userId);

        header('Content-Type: application/json; charset=utf-8');
        echo json_encode([
            'latest' => $latestNotifications,
            'unreadCount' => $unreadCount,
        ], JSON_UNESCAPED_UNICODE);
    }
}
