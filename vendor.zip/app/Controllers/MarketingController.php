<?php

namespace App\Controllers;

use App\Core\Controller;
use App\Models\Setting;
use App\Services\PlanService;

/**
 * Displays public marketing pages for TurboHostMw.
 */
class MarketingController extends Controller
{
    /**
     * Show the landing page.
     */
    public function home(): void
    {
        $settings = (new Setting())->all();
        $pageTitle = trim((string) ($settings['browser_title'] ?? '')) ?: ($settings['homepage_hero_title'] ?? 'TurboHostMw - Website Hosting Made Simple');

        $this->view('marketing/home', [
            'title' => $pageTitle,
            'settings' => $settings,
        ]);
    }

    /**
     * Show the feature overview page.
     */
    public function features(): void
    {
        $this->view('marketing/features', ['title' => 'Features']);
    }

    /**
     * Show pricing plans.
     */
    public function pricing(): void
    {
        $settings = (new Setting())->all();
        $planService = new PlanService($settings);

        $this->view('marketing/pricing', [
            'title' => 'Pricing',
            'settings' => $settings,
            'planDetails' => $planService->plans(),
        ]);
    }

    /**
     * Show company information.
     */
    public function about(): void
    {
        $this->view('marketing/about', ['title' => 'About TurboHostMw']);
    }

    /**
     * Show contact information and inquiry form.
     */
    public function contact(): void
    {
        $this->view('marketing/contact', ['title' => 'Contact']);
    }

    /**
     * Show frequently asked questions.
     */
    public function faq(): void
    {
        $this->view('marketing/faq', ['title' => 'FAQ']);
    }
}
